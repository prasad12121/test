$(document).ready(function() {
    
    // $('div').first().css('background-color', 'blue');
    // $('div').last().css('background-color', 'blue');
    // $('div').not('.p').css('background-color', 'blue');
    $('div').filter('.div').css('background-color', 'blue');

});