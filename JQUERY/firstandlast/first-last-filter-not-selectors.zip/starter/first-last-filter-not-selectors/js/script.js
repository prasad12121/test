$(document).ready(function() {
    
    // code ..

});