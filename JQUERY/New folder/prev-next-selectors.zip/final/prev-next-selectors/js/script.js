$(document).ready(function() {
    
    $('.fourth').prevAll().css('color', 'orange');

});