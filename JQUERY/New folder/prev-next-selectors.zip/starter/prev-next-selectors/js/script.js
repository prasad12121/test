$(document).ready(function() {
    
    // code ...

});