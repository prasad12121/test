$(document).ready(function() {
 
    // code ...
    
});